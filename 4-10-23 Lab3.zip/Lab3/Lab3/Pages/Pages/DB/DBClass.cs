﻿using Lab2.Pages.DataClasses;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Net.NetworkInformation;

namespace Lab2.Pages.DB
{
    public class DBClass
    {
        // Connection at the Class Level
        public static SqlConnection LabDBConnection = new SqlConnection();

        // Connection String
        private static readonly String? LabDBConnString = "Server=LocalHost;Database=Lab3;Trusted_Connection=True";

        // Connection at the Class Level
        public static SqlConnection AuthDBConnection = new SqlConnection();

        // Connection String
        private static readonly String? AuthDBConnString = "Server=LocalHost;Database=AUTH;Trusted_Connection=True";



        // Reads the data in the faculty table
        public static SqlDataReader FacultyReader()
        {

            SqlCommand cmdFacultyRead = new SqlCommand();
            cmdFacultyRead.Connection = LabDBConnection;
            cmdFacultyRead.Connection.ConnectionString = LabDBConnString;
            cmdFacultyRead.CommandText = "SELECT * FROM Faculty";

            cmdFacultyRead.Connection.Open();

            SqlDataReader tempReader = cmdFacultyRead.ExecuteReader();

            return tempReader;
        }

        // Adds a new student when signing up for office hours
        public static int InsertStudent(Student s)
        {
            String sqlQuery = "INSERT INTO Student (StudentFirst, StudentLast, StudentEmailAddress, StudentPhoneNumber, Username) OUTPUT INSERTED.StudentID VALUES('" + s.StudentFirst + "','" + s.StudentLast + "','" + s.StudentEmailAddress + "','" + s.StudentPhoneNumber + "','" + s.Username + "');";

            SqlCommand cmdStudentRead = new SqlCommand();
            cmdStudentRead.Connection = LabDBConnection;
            cmdStudentRead.Connection.ConnectionString = LabDBConnString;
            cmdStudentRead.CommandText = sqlQuery;
            cmdStudentRead.Connection.Open();

            int studentId = (int)cmdStudentRead.ExecuteScalar();

            cmdStudentRead.Connection.Close();

            return studentId;
        }

        // Adds a new student when signing up for office hours
        public static int InsertFaculty(Faculty f)
        {
            String sqlQuery = "INSERT INTO Faculty (FacultyFirst, FacultyLast, FacultyEmailAddress, FacultyPhoneNumber, OfficeLocation, Username) OUTPUT INSERTED.FacultyID VALUES('" + f.FacultyFirst + "','" + f.FacultyLast + "','" + f.FacultyEmailAddress + "','" + f.FacultyPhoneNumber + "','" + f.OfficeLocation + "','" + f.Username + "');";

            SqlCommand cmdStudentRead = new SqlCommand();
            cmdStudentRead.Connection = LabDBConnection;
            cmdStudentRead.Connection.ConnectionString = LabDBConnString;
            cmdStudentRead.CommandText = sqlQuery;
            cmdStudentRead.Connection.Open();

            int studentId = (int)cmdStudentRead.ExecuteScalar();

            cmdStudentRead.Connection.Close();

            return studentId;
        }



        // Genereal Query Reader to run and return any SELECT query
        public static SqlDataReader GeneralReaderQuery(string sqlQuery)
        {

            SqlCommand cmdGeneralRead = new SqlCommand();
            cmdGeneralRead.Connection = LabDBConnection;
            cmdGeneralRead.Connection.ConnectionString = LabDBConnString;
            cmdGeneralRead.CommandText = sqlQuery;
            cmdGeneralRead.Connection.Open();
            SqlDataReader tempReader = cmdGeneralRead.ExecuteReader();

            return tempReader;
        }


        public static SqlDataReader SpecificQueue(String username)
        {
            SqlCommand cmdSpecFacultyRead = new SqlCommand();
            cmdSpecFacultyRead.Connection = LabDBConnection;
            cmdSpecFacultyRead.Connection.ConnectionString = LabDBConnString;
            cmdSpecFacultyRead.CommandText = "SELECT Faculty.FacultyFirst, Faculty.FacultyLast, OfficeHours.OfficeHoursDays, OfficeHours.OHStartTime, OfficeHours.OHEndTime, OfficeHours.WaitingRoom FROM OfficeHours JOIN Faculty ON OfficeHours.FacultyID = Faculty.FacultyID JOIN Queue ON Queue.OfficeHoursID = OfficeHours.OfficeHoursID JOIN Student ON Queue.StudentID = Student.StudentID WHERE Student.Username = '" + username + "'";
            cmdSpecFacultyRead.Connection.Open();
            SqlDataReader tempReader = cmdSpecFacultyRead.ExecuteReader();

            return tempReader;
        }
        public static SqlDataReader SpecificOfficeHours(int facultyid)
        {
            SqlCommand cmdSpecFacultyRead = new SqlCommand();
            cmdSpecFacultyRead.Connection = LabDBConnection;
            cmdSpecFacultyRead.Connection.ConnectionString = LabDBConnString;
            cmdSpecFacultyRead.CommandText = "SELECT Faculty.FacultyFirst, Faculty.FacultyLast, OfficeHours.OfficeHoursDays, OfficeHours.OHStartTime, OfficeHours.OHEndTime, Faculty.OfficeLocation FROM Faculty INNER JOIN OfficeHours ON Faculty.FacultyID = OfficeHours.FacultyID WHERE Faculty.FacultyID = " + facultyid;
            cmdSpecFacultyRead.Connection.Open();
            SqlDataReader tempReader = cmdSpecFacultyRead.ExecuteReader();

            return tempReader;
        }

        public static int InsertQueue(Queue q)
        {
            string sqlQuery = "INSERT INTO Queue (StudentFirst, StudentLast, StudentID, OfficeHoursID) VALUES('" + q.StudentFirst + "','" + q.StudentLast + "','" + q.StudentID + "','" + q.OfficeHoursID + "');";

            SqlCommand cmdStudentRead = new SqlCommand();
            cmdStudentRead.Connection = LabDBConnection;
            cmdStudentRead.Connection.ConnectionString = LabDBConnString;
            cmdStudentRead.CommandText = sqlQuery;
            cmdStudentRead.Connection.Open();

            int officehourID = (int)cmdStudentRead.ExecuteScalar();

            cmdStudentRead.Connection.Close();

            return officehourID;
        }

        public static SqlDataReader GetStudentInfo(String username)
        {
            SqlCommand cmdInfoRead = new SqlCommand();
            cmdInfoRead.Connection = LabDBConnection;
            cmdInfoRead.Connection.ConnectionString = LabDBConnString;
            cmdInfoRead.CommandText = "SELECT StudentFirst, StudentLast, StudentEmailAddress, StudentPhoneNumber FROM Student WHERE Username = '" + username + "';";

            cmdInfoRead.Connection.Open();
            SqlDataReader tempReader = cmdInfoRead.ExecuteReader();

            return tempReader;
        }

        public static bool HashedParameterLogin(string Username, string Password)
        {
            string loginQuery =
                "SELECT Password FROM HashedCredentials WHERE Username = @Username";

            SqlCommand cmdLogin = new SqlCommand();
            cmdLogin.Connection = AuthDBConnection;
            cmdLogin.Connection.ConnectionString = AuthDBConnString;

            cmdLogin.CommandText = loginQuery;
            cmdLogin.Parameters.AddWithValue("@Username", Username);

            cmdLogin.Connection.Open();

            // ExecuteScalar() returns back data type Object
            // Use a typecast to convert this to an int.
            // Method returns first column of first row.
            SqlDataReader hashReader = cmdLogin.ExecuteReader();
            if (hashReader.Read())
            {
                string correctHash = hashReader["Password"].ToString();

                if (PasswordHash.ValidatePassword(Password, correctHash))
                {
                    return true;
                }
            }

            return false;
        }

        public static void CreateHashedUser(string Username, string Password)
        {
            string loginQuery =
                "INSERT INTO HashedCredentials (Username,Password) values (@Username, @Password)";

            SqlCommand cmdLogin = new SqlCommand();
            cmdLogin.Connection = AuthDBConnection;
            cmdLogin.Connection.ConnectionString = AuthDBConnString;

            cmdLogin.CommandText = loginQuery;
            cmdLogin.Parameters.AddWithValue("@Username", Username);
            cmdLogin.Parameters.AddWithValue("@Password", PasswordHash.HashPassword(Password));

            cmdLogin.Connection.Open();

            // ExecuteScalar() returns back data type Object
            // Use a typecast to convert this to an int.
            // Method returns first column of first row.
            cmdLogin.ExecuteNonQuery();

        }

        public static bool StoredProcedureLogin(string Username, string Password)
        {

            SqlCommand cmdProductRead = new SqlCommand();
            cmdProductRead.Connection = AuthDBConnection;
            cmdProductRead.Connection.ConnectionString = AuthDBConnString;
            cmdProductRead.CommandType = System.Data.CommandType.StoredProcedure;
            cmdProductRead.Parameters.AddWithValue("@Username", Username);
            cmdProductRead.Parameters.AddWithValue("@Password", Password);
            cmdProductRead.CommandText = "sp_Lab3Login";
            cmdProductRead.Connection.Open();
            if (((int)cmdProductRead.ExecuteScalar()) > 0)
            {
                return true;
            }

            return false;
        }



    }   
}
