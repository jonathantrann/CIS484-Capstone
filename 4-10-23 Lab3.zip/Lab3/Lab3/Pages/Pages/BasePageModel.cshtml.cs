using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Lab3.Pages
{
    public class BasePageModelModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
