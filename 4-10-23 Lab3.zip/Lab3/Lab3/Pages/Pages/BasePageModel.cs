﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Lab3.Pages
{
    public class BasePageModel : PageModel
    {
        public bool IsLoggedIn => HttpContext.Session.GetString("username") != null;
        public string Username => HttpContext.Session.GetString("username");
    }
}
