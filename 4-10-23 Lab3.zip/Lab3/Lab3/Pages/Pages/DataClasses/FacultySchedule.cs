﻿namespace Lab2.Pages.DataClasses
{
    public class FacultySchedule
    {
        public int FacultyScheduleID { get; set; }
        public int FacultyID { get; set; }

        public int ClassID { get; set; }
    }
}
