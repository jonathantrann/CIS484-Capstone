﻿namespace Lab1.Pages.DataClasses
{
    public class JoinTables
    {

    }
}
