﻿namespace Lab2.Pages.DataClasses
{
    public class Faculty
    {

        public int FacultyID { get; set; }

        public String? FacultyFirst { get; set; }

        public String? FacultyLast { get; set; }

        public String? FacultyEmailAddress { get; set; }

        public String? FacultyPhoneNumber { get; set; }

        public String? OfficeLocation { get; set; }

        public String? Username { get; set; }
    }
}
