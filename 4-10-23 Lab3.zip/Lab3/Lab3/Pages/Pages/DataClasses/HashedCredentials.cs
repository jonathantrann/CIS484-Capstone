﻿namespace Lab2.Pages.DataClasses
{
    public class HashedCredentials
    {
        public int HashedCredentialsID { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
