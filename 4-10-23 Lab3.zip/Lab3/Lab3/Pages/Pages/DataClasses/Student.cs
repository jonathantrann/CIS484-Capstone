﻿namespace Lab2.Pages.DataClasses
{
    public class Student
    {
        public int StudentID { get; set; }

        public String? StudentFirst { get; set; }

        public String? StudentLast { get; set; }

        public String? StudentEmailAddress { get; set; }

        public String? StudentPhoneNumber { get; set; }

        public int StudentPartnerID { get; set; }

        public String? Username { get; set; }
    }
}
