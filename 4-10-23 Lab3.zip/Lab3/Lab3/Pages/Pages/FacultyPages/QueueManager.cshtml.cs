using Lab2.Pages.DataClasses;
using Lab2.Pages.DB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Net.Mail;

namespace Lab2.Pages.FacultyPages
{
    public class QueueManagerModel : PageModel
    {
        // Create new list for student and queue
       // public List<Student> StudentList { get; set; }
        public List<Queue> QueueList { get; set; }


        public QueueManagerModel()
        {
            //StudentList = new List<Student>();
            QueueList = new List<Queue>();
        }


        public void OnGet()
        {
            // Reads in data from the student table and converts it to strings
            string sqlQuery = "SELECT Student.StudentFirst, Student.StudentLast FROM Student INNER JOIN QUEUE ON Student.StudentID = Queue.StudentID";
            SqlDataReader singleQueue = DBClass.GeneralReaderQuery(sqlQuery);

            while (singleQueue.Read())
            {
                QueueList.Add(new Queue
                {
                    QueueID = Int32.Parse(singleQueue["QueueID"].ToString()),
                    StudentFirst = singleQueue["StudentFirst"].ToString(),
                    StudentLast = singleQueue["StudentLast"].ToString(),
                    StudentID = Int32.Parse(singleQueue["StudentID"].ToString()),
                    OfficeHoursID = Int32.Parse(singleQueue["OfficeHoursID"].ToString()),

                });
                
            }
            DBClass.LabDBConnection.Close();

            int count = QueueList.Count;

        }


    }
    

}
