using Lab2.Pages.DataClasses;
using Lab2.Pages.DB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Lab2.Pages.Login
{
    public class CreateStudentModel : PageModel
    {
        [BindProperty]
        public Student NewStudent { get; set; }

        public void OnGet()
        {
        }

        public IActionResult OnPost(string button)
        {
            
            int studentId = DBClass.InsertStudent(NewStudent);

            DBClass.LabDBConnection.Close();

            return RedirectToPage("StudentHash");
        }
    }
}
