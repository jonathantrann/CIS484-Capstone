using Lab2.Pages.DataClasses;
using Lab2.Pages.DB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace Lab2.Pages.Login
{
    public class CreateFacultyModel : PageModel
    {
        [BindProperty]
        public Faculty? NewFaculty { get; set; }


        public void OnGet()
        {
        }

        public IActionResult OnPost(string button)
        {
            int facultyId = DBClass.InsertFaculty(NewFaculty);

            DBClass.LabDBConnection.Close();

            return RedirectToPage("FacultyLogin");
        }

    }
}
