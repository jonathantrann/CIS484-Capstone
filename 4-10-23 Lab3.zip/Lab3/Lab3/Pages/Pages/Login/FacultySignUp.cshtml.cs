using Lab2.Pages.DataClasses;
using Lab2.Pages.DB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Lab2.Pages.Login
{
    public class FacultySignUpModel : PageModel
    {
        [BindProperty]
        public Credentials NewCred { get; set; }

        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            DBClass.InsertCredentials(NewCred);

            DBClass.LabDBConnection.Close();

            return RedirectToPage("FacultyLogin");
        }
    }
}