using Lab2.Pages.DataClasses;
using Lab2.Pages.DB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using System.Net.NetworkInformation;
using System.Xml.Linq;
using Microsoft.AspNetCore.Http;

namespace Lab2.Pages.StudentPages
{
    public class SignUpModel : PageModel
    {
        // Create new list for student and queue
        // public List<Student> StudentList { get; set; }
        [BindProperty] public int SelectedFaculty { get; set; }
        //public List<Queue> QueueList { get; set; }
        public List<OfficeHours> OHList { get; set; }
        public List<Faculty> FacultyList { get; set; }
        [BindProperty] public int currentStudentID { get; set; }
        [BindProperty] public int selectedOfficeHoursID { get; set; }

        [BindProperty] public int selectedFacultyID { get; set; }

        public Queue NewQueue { get; set; }


        public List<SpecificOfficeHours> SpecificOfficeHoursList;

        public SignUpModel()
        {
            OHList = new List<OfficeHours>();
            FacultyList = new List<Faculty>();
            SpecificOfficeHoursList = new List<SpecificOfficeHours>();
            NewQueue = new Queue();


        }

        public void OnGet()
        {
            SqlDataReader FacultyReader = DBClass.FacultyReader();

            while (FacultyReader.Read())
            {

                FacultyList.Add(new Faculty
                {
                    FacultyID = Int32.Parse(FacultyReader["FacultyID"].ToString()),
                    FacultyFirst = FacultyReader["FacultyFirst"].ToString(),
                    FacultyLast = FacultyReader["FacultyLast"].ToString()

                });

            }
            DBClass.LabDBConnection.Close();
        }
        public IActionResult OnPostSingleSelect()
        {

            SqlDataReader SpecificOfficeHoursReader = DBClass.SpecificOfficeHours(SelectedFaculty);

            while (SpecificOfficeHoursReader.Read())
            {
                SpecificOfficeHoursList.Add(new SpecificOfficeHours
                {
                    FacultyFirst = SpecificOfficeHoursReader["FacultyFirst"].ToString(),
                    FacultyLast = SpecificOfficeHoursReader["FacultyLast"].ToString(),
                    OfficeHoursDays = SpecificOfficeHoursReader["OfficeHoursDays"].ToString(),
                    OHStartTime = SpecificOfficeHoursReader["OHStartTime"].ToString(),
                    OHEndTime = SpecificOfficeHoursReader["OHEndTime"].ToString(),
                    OfficeLocation = SpecificOfficeHoursReader["OfficeLocation"].ToString()
                });
            }
            DBClass.LabDBConnection.Close();

            SqlDataReader FacultyReader = DBClass.FacultyReader();

            while (FacultyReader.Read())
            {

                FacultyList.Add(new Faculty
                {
                    FacultyID = Int32.Parse(FacultyReader["FacultyID"].ToString()),
                    FacultyFirst = FacultyReader["FacultyFirst"].ToString(),
                    FacultyLast = FacultyReader["FacultyLast"].ToString()

                });

            }
            DBClass.LabDBConnection.Close();

            return Page();

        }
        public IActionResult OnPostAddToQueue(string button)
        {
            NewQueue.OfficeHoursID = selectedOfficeHoursID;
            NewQueue.StudentID = currentStudentID;
            int officehourID = DBClass.InsertQueue(NewQueue);
            NewQueue.OfficeHoursID = officehourID;
            DBClass.InsertQueue(NewQueue);
            DBClass.LabDBConnection.Close();

            return Page();

        }

    }
}
