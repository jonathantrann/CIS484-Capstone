using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Lab2.Pages.HTML
{
    public class HTML_HELPModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
