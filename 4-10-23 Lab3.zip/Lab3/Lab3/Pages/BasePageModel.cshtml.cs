using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Lab2.Pages
{
    public class BasePageModelModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
