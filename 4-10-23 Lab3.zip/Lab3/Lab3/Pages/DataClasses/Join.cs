﻿//namespace Lab2.Pages.DataClasses
//{
//    public class Join
//    {
//        //Student
//        public int StudentID { get; set; }

//        public String? StudentFirst { get; set; }

//        public String? StudentLast { get; set; }

//        public String? StudentEmailAddress { get; set; }

//        public String? StudentPhoneNumber { get; set; }
//        public int StudentPartnerID { get; set; }

//        //Faculty
//        public int FacultyID { get; set; }

//        public String? FacultyFirst { get; set; }

//        public String? FacultyLast { get; set; }

//        public String? FacultyEmailAddress { get; set; }

//        public String? FacultyPhoneNumber { get; set; }

//        public String? OfficeLocation { get; set; }

//        //Class

//        public int ClassID { get; set; }

//        public String? ClassName { get; set; }

//        public int ClassSection { get; set; }

//        public String? ClassStartTime { get; set; }

//        public String? ClassEndTime { get; set; }

//        public String? MeetingDays { get; set; }

//        public int CreditHours { get; set; }

//        public String? ClassDescription { get; set; }

//        public String? ClassLocation { get; set; }

//        public int ClassCapacity { get; set; }

//        //OfficeHours

//        public int OfficeHoursID { get; set; }

//        public String? OfficeHoursDays { get; set; }

//        public String? OHStartTime { get; set; } //Military Time

//        public String? OHEndTime { get; set; } //Military Time

//        public String? WaitingRoom { get; set; }


//        //Meeting

//        public int MeetingID { get; set; }

//        public String? MeetingLocation { get; set; }

//        public String? MeetingDate { get; set; } //Month Day, Year

//        public String? MeetStartTime { get; set; } //Military Time

//        public String? MeetEndTime { get; set; } //Military Time

//        public String? MeetingPurpose { get; set; }


//        //Queue

//        public int QueueID { get; set; } 

//        //FacultySchedule

//        //StudentSchedule

//        public int StudentScheduleID { get; set; }

//        public int TotalCreditHours { get; set; }

//    }
//}
