﻿namespace Lab3.Pages.DataClasses
{
    public class JoinTables
    {

    }
}
