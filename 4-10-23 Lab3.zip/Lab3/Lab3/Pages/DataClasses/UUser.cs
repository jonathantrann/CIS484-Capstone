﻿namespace Lab3.Pages.DataClasses
{
    public class UUser
    {
    }
}
