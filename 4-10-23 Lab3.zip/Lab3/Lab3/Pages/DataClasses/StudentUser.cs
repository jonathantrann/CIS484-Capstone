﻿namespace Lab2.Pages.DataClasses
{
    public class User
    {

        

    }
}
