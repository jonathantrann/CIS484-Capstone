﻿public class Credentials
{
    public int CredentialsID { get; set; }
    public string Username { get; set; }
    public string Password { get; set; }
    public int StudentID { get; set; }

    public int FacultyID { get; set; }
}
