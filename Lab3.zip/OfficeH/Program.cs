using Microsoft.AspNetCore.Authentication.Cookies;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();

builder.Services.AddSession();

var app = builder.Build();

//public void configureServices(IServiceCollection services)
//{
//    services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme).AddCookie(options
//        =>
//    {
//        options.LoginPath = "/Student/DBLogin";
//    });
//}

//public void configure(IApplicationBuilder app, IWebHostEnvironment env)
//{
//    app.UseAuthentication();
//    app.UseAuthorization();
//}
// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseSession();

app.UseRouting();

app.UseAuthorization();

app.MapRazorPages();

app.Run();
