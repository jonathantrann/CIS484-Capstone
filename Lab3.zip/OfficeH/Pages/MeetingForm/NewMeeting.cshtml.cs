using Azure.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using OfficeHours.Pages.DataClasses;
using OfficeHours.Pages.DB;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;

namespace OfficeHours.Pages.MeetingForm
{
    public class New_MeetingModel : PageModel
    {
        [BindProperty]

        public MeetingClass NewMeeting { get; set; }

        [BindProperty(SupportsGet =true)]
        public int FormID { get; set; }

        [BindProperty]
        [Required]
        public String? Purpose { get; set; }

        [BindProperty]
        [Required]
        public String? Type { get; set; }

        [BindProperty]
        [Required]
        public String? Date { get; set; }

        [BindProperty]
        public int FacultyID { get; set; }

        [BindProperty]
        public int StudentID { get; set; }

        [BindProperty]
        public int ClassID { get; set; }

        public IActionResult OnGet()
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                return RedirectToPage("/Student/DBLogin");
            }
            else
            {
                var options = new CookieOptions
                {
                    Expires = DateTime.Now.AddMinutes(30)
                };
                Response.Cookies.Append("username", HttpContext.Session.GetString("username"), options);
            }
            return Page();
        }

        public IActionResult OnPost()
        {
            DBClass.InsertMeeting(NewMeeting);

            DBClass.OfficeHoursDBConnection.Close();

            return RedirectToPage("Index");
        }

        public IActionResult OnPostClearHandler()
        {
            ModelState.Clear();
            NewMeeting.Purpose = "";
            NewMeeting.Type = "";
            NewMeeting.Date = "";
            return Page();
        }

        public IActionResult OnPostPopulateHandler()
        {
            ModelState.Clear();
            NewMeeting.Purpose = "Grade Check";
            NewMeeting.Type = "Group";
            NewMeeting.Date = "2/19/2022";

            return Page();

        }
    }
}
