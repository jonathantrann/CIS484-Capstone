using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using OfficeHours.Pages.DataClasses;
using OfficeHours.Pages.DB;
using System.Data.SqlClient;

namespace OfficeHours.Pages.MeetingForm
{
    public class IndexModel : PageModel
    {
        public List<MeetingClass> MeetingList { get; set; }

        public String LoginMessage { get; set; }

        //Constructor
        public IndexModel()
        {
            MeetingList = new List<MeetingClass>();

        }

        public void OnGet()
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                Response.Redirect("/Student/DBLogin");
            }
            else
            {
                SqlDataReader meetingFormReader = DBClass.MeetingFormReader();

                while (meetingFormReader.Read())
                {
                    MeetingList.Add(new MeetingClass
                    {
                        Purpose = meetingFormReader["Purpose"].ToString(),
                        Type = meetingFormReader["Type"].ToString(),
                        Date = meetingFormReader["Date"].ToString(),

                    });


                }
                //Close your connection in DBClass
                DBClass.OfficeHoursDBConnection.Close();
                // Set a cookie to keep the user signed in for 30 minutes
                var options = new CookieOptions
                {
                    Expires = DateTime.Now.AddMinutes(30)
                };
                Response.Cookies.Append("username", HttpContext.Session.GetString("username"), options);
            }


        }
    }
}
//        public IActionResult OnPost()
//        {
//            string insertQuery = "INSERT INTO MeetingForm (FacultyID, StudentID, ClassID) VALUES (";  
//            insertQuery += MeetingClass.ReferenceEquals.
//        }
//    }
//}
