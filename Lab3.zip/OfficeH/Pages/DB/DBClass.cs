﻿using OfficeHours.Pages.DataClasses;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
namespace OfficeHours.Pages.DB
{
    public class DBClass
    {
        //Connection at the Class Level
        public static SqlConnection OfficeHoursDBConnection = new SqlConnection();

        //Connection String
        private static readonly String? OfficeHoursDBConnString = "Server=Localhost;Database=Lab3;Trusted_Connection=True";
        private static readonly String? AuthConnString = "Server=Localhost;Database=AUTH;Trusted_Connection=True";
        public static SqlDataReader MeetingFormReader()
        {
            SqlCommand cmdProductRead = new SqlCommand();
            cmdProductRead.Connection = OfficeHoursDBConnection;
            cmdProductRead.Connection.ConnectionString = OfficeHoursDBConnString;
            cmdProductRead.CommandText = "Select * FROM MeetingForm";

            cmdProductRead.Connection.Open();

            SqlDataReader tempReader = cmdProductRead.ExecuteReader();

            return tempReader;
        }
        public static SqlDataReader facultyReader()
        {
            SqlCommand cmdProductRead = new SqlCommand();
            cmdProductRead.Connection = OfficeHoursDBConnection;
            cmdProductRead.Connection.ConnectionString = OfficeHoursDBConnString;
            cmdProductRead.CommandText = "SELECT * FROM FACULTY";

            cmdProductRead.Connection.Open();

            SqlDataReader tempReader = cmdProductRead.ExecuteReader();

            return tempReader;
        }
        //public static void InsertMeeting(MeetingClass p)
        //      {
        //          String sqlQuery = "INSERT INTO MeetingForm (Purpose,Type,Date) VALUES (";
        //          sqlQuery += "'" + p.Purpose + "', '";
        //	sqlQuery += p.Type + "', '";
        //	sqlQuery += p.Date + "')";

        //          SqlCommand cmdProductRead = new SqlCommand();
        //          cmdProductRead.Connection = OfficeHoursDBConnection;
        //          cmdProductRead.Connection.ConnectionString = OfficeHoursDBConnString;
        //          cmdProductRead.CommandText = sqlQuery;

        //          cmdProductRead.Connection.Open();

        //            cmdProductRead.ExecuteNonQuery();
        //      }

        public static void InsertMeeting(MeetingClass p)

        {

            string sqlQuery = "INSERT INTO MeetingForm (Purpose, Type, Date) VALUES (@Purpose, @Type, @Date)";



            SqlCommand cmdInsertMeeting = new SqlCommand();

            cmdInsertMeeting.Connection = OfficeHoursDBConnection;

            cmdInsertMeeting.Connection.ConnectionString = OfficeHoursDBConnString;

            cmdInsertMeeting.CommandText = sqlQuery;



            cmdInsertMeeting.Parameters.AddWithValue("@Purpose", p.Purpose);

            cmdInsertMeeting.Parameters.AddWithValue("@Type", p.Type);

            cmdInsertMeeting.Parameters.AddWithValue("@Date", p.Date);



            cmdInsertMeeting.Connection.Open();

            cmdInsertMeeting.ExecuteNonQuery();

        }

        public static int LoginQuery(string loginQuery)
        {
            // This method expects to receive an SQL SELECT
            // query that uses the COUNT command.

            SqlCommand cmdLogin = new SqlCommand();
            cmdLogin.Connection = OfficeHoursDBConnection;
            cmdLogin.Connection.ConnectionString = OfficeHoursDBConnString;
            cmdLogin.CommandText = loginQuery;
            cmdLogin.Connection.Open();

            // ExecuteScalar() returns back data type Object
            // Use a typecast to convert this to an int.
            // Method returns first column of first row.
            int rowCount = (int)cmdLogin.ExecuteScalar();

            return rowCount;
        }

        public static int SecureLogin(string Username, string Password)
        {
            string loginQuery =
            "SELECT COUNT(*) FROM Credentials where Username = @Username and Password = @Password";
            SqlCommand cmdLogin = new SqlCommand();
            cmdLogin.Connection = OfficeHoursDBConnection;
            cmdLogin.Connection.ConnectionString = OfficeHoursDBConnString;
            cmdLogin.CommandText = loginQuery;
            cmdLogin.Parameters.AddWithValue("@Username", Username);
            cmdLogin.Parameters.AddWithValue("@Password", Password);
            cmdLogin.Connection.Open();
            // ExecuteScalar() returns back data type Object
            // Use a typecast to convert this to an int.
            // Method returns first column of first row.
            int rowCount = (int)cmdLogin.ExecuteScalar();
            return rowCount;
        }

        public static SqlDataReader GeneralReaderQuery(string sqlQuery)
        {

            SqlCommand cmdProductRead = new SqlCommand();
            cmdProductRead.Connection = OfficeHoursDBConnection;
            cmdProductRead.Connection.ConnectionString = OfficeHoursDBConnString;
            cmdProductRead.CommandText = sqlQuery;
            cmdProductRead.Connection.Open();
            SqlDataReader tempReader = cmdProductRead.ExecuteReader();

            return tempReader;

        }

        public static void InsertQuery(string sqlQuery)
        {

            SqlCommand cmdProductRead = new SqlCommand();
            cmdProductRead.Connection = OfficeHoursDBConnection;
            cmdProductRead.Connection.ConnectionString = OfficeHoursDBConnString;
            cmdProductRead.CommandText = sqlQuery;
            cmdProductRead.Connection.Open();
            cmdProductRead.ExecuteNonQuery();

        }

        //public static bool HashedParameterLogin(string Username, string Password)
        //{
        //    string loginQuery =
        //        "SELECT Password FROM HashedCredentials WHERE Username = @Username";

        //    SqlCommand cmdLogin = new SqlCommand();
        //    cmdLogin.Connection = OfficeHoursDBConnection;
        //    cmdLogin.Connection.ConnectionString = AuthConnString;

        //    cmdLogin.CommandText = loginQuery;
        //    cmdLogin.Parameters.AddWithValue("@Username", Username);

        //    cmdLogin.Connection.Open();

        //    // ExecuteScalar() returns back data type Object
        //    // Use a typecast to convert this to an int.
        //    // Method returns first column of first row.
        //    SqlDataReader hashReader = cmdLogin.ExecuteReader();
        //    if (hashReader.Read())
        //    {
        //        string correctHash = hashReader["Password"].ToString();

        //        if (PasswordHash.ValidatePassword(Password, correctHash))
        //        {
        //            return true;
        //        }
        //    }

        //    return false;
        //}


        public static bool HashedParameterLogin(string Username, string Password)

        {

            SqlCommand cmdLogin = new SqlCommand();

            cmdLogin.Connection = OfficeHoursDBConnection;

            cmdLogin.Connection.ConnectionString = AuthConnString;



            cmdLogin.CommandType = CommandType.StoredProcedure;

            cmdLogin.CommandText = "sp_Lab3Login";

            cmdLogin.Parameters.AddWithValue("@Username", Username);

            cmdLogin.Parameters.AddWithValue("@Password", Password);



            cmdLogin.Connection.Open();



            // ExecuteScalar() returns back data type Object 

            // Use a typecast to convert this to an int. 

            // Method returns first column of first row. 

            SqlDataReader hashReader = cmdLogin.ExecuteReader();

            if (hashReader.Read())

            {

                string correctHash = hashReader["Password"].ToString();



                if (PasswordHash.ValidatePassword(Password, correctHash))

                {

                    return true;

                }

            }



            return false;

        }

        public static void CreateHashedUser(string Username, string Password)
        {
            string loginQuery =
                "INSERT INTO HashedCredentials (Username,Password) values (@Username, @Password)";

            SqlCommand cmdLogin = new SqlCommand();
            cmdLogin.Connection = OfficeHoursDBConnection;
            cmdLogin.Connection.ConnectionString = AuthConnString;

            cmdLogin.CommandText = loginQuery;
            cmdLogin.Parameters.AddWithValue("@Username", Username);
            cmdLogin.Parameters.AddWithValue("@Password", PasswordHash.HashPassword(Password));

            cmdLogin.Connection.Open();

            // ExecuteScalar() returns back data type Object
            // Use a typecast to convert this to an int.
            // Method returns first column of first row.
            cmdLogin.ExecuteNonQuery();

        }

        public static void CreateHashedFac(string Username, string Password)
        {
            string loginQuery =
                "INSERT INTO HashedFacCredentials (Username,Password) values (@Username, @Password)";

            SqlCommand cmdLogin = new SqlCommand();
            cmdLogin.Connection = OfficeHoursDBConnection;
            cmdLogin.Connection.ConnectionString = AuthConnString;

            cmdLogin.CommandText = loginQuery;
            cmdLogin.Parameters.AddWithValue("@Username", Username);
            cmdLogin.Parameters.AddWithValue("@Password", PasswordHash.HashPassword(Password));

            cmdLogin.Connection.Open();

            // ExecuteScalar() returns back data type Object
            // Use a typecast to convert this to an int.
            // Method returns first column of first row.
            cmdLogin.ExecuteNonQuery();

        }

        public static bool HashedFacParameterLogin(string Username, string Password)
        {
            string loginQuery =
                "SELECT Password FROM HashedFacCredentials WHERE Username = @Username";

            SqlCommand cmdLogin = new SqlCommand();
            cmdLogin.Connection = OfficeHoursDBConnection;
            cmdLogin.Connection.ConnectionString = AuthConnString;

            cmdLogin.CommandText = loginQuery;
            cmdLogin.Parameters.AddWithValue("@Username", Username);

            cmdLogin.Connection.Open();

            // ExecuteScalar() returns back data type Object
            // Use a typecast to convert this to an int.
            // Method returns first column of first row.
            SqlDataReader hashReader = cmdLogin.ExecuteReader();
            if (hashReader.Read())
            {
                string correctHash = hashReader["Password"].ToString();

                if (PasswordHash.ValidatePassword(Password, correctHash))
                {
                    return true;
                }
            }

            return false;
        }

        public static List<string> GetFacultyNames()
        {
            List<string> facultyNames = new List<string>();
            using (SqlConnection connection = new SqlConnection(OfficeHoursDBConnString))
            {
                connection.Open();
                string query = "SELECT FacultyName FROM Faculty";
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    string facultyName = reader.GetString(0);
                    facultyNames.Add(facultyName);
                }
                reader.Close();
            }
            return facultyNames;
        }

        //public static void UpdateQueue(QueueClass p)
        //{
        //    foreach (var StudentID in Queue)
        //    {
        //        if (p.StudentID == Queue.Student)
        //        {
        //            string sqlQuery = "UPDATE Queue SET";

        //            sqlQuery += "QueuePosition=1";

        //            SqlCommand cmdProductRead = new SqlCommand();
        //            cmdProductRead.Connection = new SqlConnection();
        //            cmdProductRead.Connection.ConnectionString = OfficeHoursDBConnString;
        //            cmdProductRead.CommandText = sqlQuery;
        //            cmdProductRead.Connection.Open();
        //            cmdProductRead.ExecuteNonQuery();
        //        }
        //        else
        //        {
        //            string sqlQuery = "UPDATE Queue SET";

        //            sqlQuery += "QueuePosition = QueuePosition + 1";

        //            SqlCommand cmdProductRead = new SqlCommand();
        //            cmdProductRead.Connection = new SqlConnection();
        //            cmdProductRead.Connection.ConnectionString = OfficeHoursDBConnString;
        //            cmdProductRead.CommandText = sqlQuery;
        //            cmdProductRead.Connection.Open();
        //            cmdProductRead.ExecuteNonQuery();
        //        }


        //    }



        //}

        public static void UpdateQueue(QueueClass queue)
        {
            using (SqlConnection connection = new SqlConnection(OfficeHoursDBConnString))
            {
                connection.Open();

                int studentID;
                for (int i = 0; i < queue.StudentID; i++)
                {
                    studentID = queue.StudentID;

                    if (studentID == queue.StudentID)
                    {
                        string sqlQuery = "UPDATE Queue SET QueuePosition=1 WHERE StudentID=@StudentID";
                        SqlCommand command = new SqlCommand(sqlQuery, connection);
                        command.Parameters.AddWithValue("@StudentID", studentID);
                        command.ExecuteNonQuery();
                    }
                    else
                    {
                        string sqlQuery = "UPDATE Queue SET QueuePosition=QueuePosition+1 WHERE StudentID=@StudentID";
                        SqlCommand command = new SqlCommand(sqlQuery, connection);
                        command.Parameters.AddWithValue("@StudentID", studentID);
                        command.ExecuteNonQuery();
                    }
                }
            }

            //    public static void RemoveQueue(QueueClass queue)
            //    {

            //    }
            //}



        }

        public static void NotifyStudent(QueueClass studentToNotify)
        {
            using (SqlConnection connection = new SqlConnection(OfficeHoursDBConnString))
            {
                connection.Open();

                // Check if selected student is already at the front of the queue
                string sqlQuery = "SELECT QueuePosition FROM Queue WHERE StudentID = @StudentID";
                SqlCommand command = new SqlCommand(sqlQuery, connection);
                command.Parameters.AddWithValue("@StudentID", studentToNotify.StudentID);

                int currentQueuePosition = 0;
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        currentQueuePosition = reader.GetInt32(0);
                    }
                }

                if (currentQueuePosition == 1)
                {
                    // Selected student is already at the front of the queue, no need to update positions
                    return;
                }
                else
                {
                    // Update queue positions
                    sqlQuery = "UPDATE Queue SET QueuePosition = QueuePosition - 1 WHERE QueuePosition > 0";
                    command = new SqlCommand(sqlQuery, connection);
                    command.ExecuteNonQuery();

                    // Set selected student's queue position to 1
                    sqlQuery = "UPDATE Queue SET QueuePosition = 1 WHERE StudentID = @StudentID";
                    command = new SqlCommand(sqlQuery, connection);
                    command.Parameters.AddWithValue("@StudentID", studentToNotify.StudentID);
                    command.ExecuteNonQuery();
                }
            }
        }
    }
}