﻿namespace OfficeHours.Pages.DataClasses
{
    public class Credentials
    {
        public int CredentialsID { get; set; }

        public String? Username { get; set;}

        public String? Password { get; set;}
    }
}
