﻿namespace OfficeHours.Pages.DataClasses
{
    public class Course
    {
        public int ClassID { get; set; }

        public String? CourseName { get; set; }

        public int ClassSection { get; set; }

        public int FacultyID { get; set; }

        public int LocationRoomNumber { get; set; }
    }
}
