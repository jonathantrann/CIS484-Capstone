﻿namespace OfficeHours.Pages.DataClasses
{
    public class FacultyCredentials
    {
        public int FacultyCredentialsID { get; set; }

        public String? Username { get; set; }

        public String? Password { get; set; }
    }
}
