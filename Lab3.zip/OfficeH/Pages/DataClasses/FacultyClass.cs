﻿namespace OfficeHours.Pages.DataClasses
{
    public class FacultyClass
    {
        public int FacultyID { get; set; } 

        public String? FacultyName { get; set; }

        public String? InstructorEmail { get; set; }

        public int LocationRoomNumber { get; set; }
    }
}
