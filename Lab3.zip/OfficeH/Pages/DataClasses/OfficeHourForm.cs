﻿namespace OfficeHours.Pages.DataClasses
{
    public class OfficeHourForm
    {
        public int SessionID { get; set; }

        public String? SessionTime { get; set; }

        public int ClassID { get; set; }

        public String? FacultyID { get; set; }
    }
}
