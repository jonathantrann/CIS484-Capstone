﻿namespace OfficeHours.Pages.DataClasses
{
    public class QueueClass
    {
        public int QueueID { get; set; }

        public int NumStudentsRegistered { get; set; }

        public int QueuePosition { get; set; }

        public int SessionID { get; set; }

        public int StudentID { get; set; }


    }
}
