﻿namespace OfficeHours.Pages.DataClasses
{
    public class StudentClass
    {
        public int StudentID { get; set; }

        public String? StuName { get; set; }

        public String? Major { get; set; }

        public String? Email { get; set; }
    }
}
