﻿namespace OfficeHours.Pages.DataClasses
{
    public class Location
    {
        public int LocationRoomNumber { get; set; }

        public String? BuildingName { get; set; }
    }
}
