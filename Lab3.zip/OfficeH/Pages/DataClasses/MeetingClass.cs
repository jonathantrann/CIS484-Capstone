﻿namespace OfficeHours.Pages.DataClasses
{
    public class MeetingClass
    {
        public int FormID { get; set; }
        public String? Purpose { get; set; }

        public String? Type { get; set; }

        public String? Date { get; set; }

        public int FacultyID { get; set; }

        public int StudentID { get; set; }

        public int ClassID { get; set; }
    }
}
