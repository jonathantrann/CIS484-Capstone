using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace OfficeHours.Pages.Queue
{
    public class QueueViewModel : PageModel
    {
        public IActionResult OnGet()
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                return RedirectToPage("/Student/DBLogin");
            }
            else
            {
                var options = new CookieOptions
                {
                    Expires = DateTime.Now.AddMinutes(30)
                };
                Response.Cookies.Append("username", HttpContext.Session.GetString("username"), options); 
            }

            return Page();
        }
    }
}
