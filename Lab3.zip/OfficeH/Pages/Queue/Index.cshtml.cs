using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using OfficeHours.Pages.DB;
using System.Data.SqlClient;

namespace OfficeHours.Pages.Queue
{
    public class IndexModel : PageModel
    {
        [BindProperty]

        public int SessionID { get; set; }

        [BindProperty]

        public int StudentID { get; set; }
        public List<SelectListItem> SessionTime { get; set; }

        public List<SelectListItem> Student { get; set; }

        public void OnGet()
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                Response.Redirect("/Student/DBLogin");
            }
            else
            {
                // Populate the User SELECT control
                SqlDataReader ShopperReader = DBClass.GeneralReaderQuery("SELECT * FROM OfficeHourForm");

            SessionTime = new List<SelectListItem>();

            while (ShopperReader.Read())
            {
                SessionTime.Add(
                    new SelectListItem(
                        ShopperReader["SessionTime"].ToString(),
                        ShopperReader["SessionID"].ToString()));
            }

            DBClass.OfficeHoursDBConnection.Close();
                // Set a cookie to keep the user signed in for 30 minutes
                var options = new CookieOptions
                {
                    Expires = DateTime.Now.AddMinutes(30)
                };
                Response.Cookies.Append("username", HttpContext.Session.GetString("username"), options);
            }
        }

        public IActionResult OnPost()
        {
            string insertQuery = "INSERT INTO QUEUE (SessionID) VALUES (";
            insertQuery += SessionID + ")";

            DBClass.InsertQuery(insertQuery);

            DBClass.OfficeHoursDBConnection.Close();

            return RedirectToAction("Index");
        }

        //// Properties for Single Select Dropdown
        //[BindProperty] public int SelectedNumber { get; set; }
        //public String SelectMessage { get; set; }

        //// Properties for Handling Dates and Times
        //[BindProperty] public DateTime FullDateAndTime { get; set; }
        //[BindProperty] public DateTime JustTheDate { get; set; }
        //[BindProperty] public DateTime JustTheTime { get; set; }
        //public String DateTimeMessage { get; set; }

        //[BindProperty]
        //public int SessionID { get; set; }

        //[BindProperty]
        //public int StudentID { get; set; }
        //public void OnGet()
        //{
        //}

        //public void OnPostSingleSelect()
        //{
        //    SelectMessage = "You Selected the following option: " + SelectedNumber;
        //}


        //public void OnPostDateAndTime()
        //{
        //    DateTimeMessage = "Full Timestamp: " + FullDateAndTime.ToString("MM/dd/yy hh:mm:ss tt");
        //    DateTimeMessage += ", The Date: " + JustTheDate.ToString("MM/dd/yy");
        //    DateTimeMessage += ", The Time: " + JustTheTime.ToString("hh:mm:ss tt");

        //}

        //public IActionResult OnPost()
        //{
        //    string insertQuery = "INSERT INTO QUEUE (NumStudentsRegistered, QueuePosition, SessionID, StudentID) VALUES (";
        //    insertQuery += N
        //}
    }
}