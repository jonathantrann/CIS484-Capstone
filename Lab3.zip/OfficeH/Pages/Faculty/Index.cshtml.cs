using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using OfficeHours.Pages.DataClasses;
using OfficeHours.Pages.DB;
using System.Data.SqlClient;

namespace OfficeHours.Pages.Faculty
{
    public class IndexModel : PageModel
    {
        public List<MeetingClass> MeetingList { get; set; }

        [BindProperty]
        public int StudentID { get; set; }

        QueueClass StudentToNotify = new QueueClass();

        public IActionResult OnGet()
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                return RedirectToPage("/Student/DBLogin");
            }
            else
            {
                MeetingList = new List<MeetingClass>();

                SqlDataReader meetingFormReader = DBClass.MeetingFormReader();

                while (meetingFormReader.Read())
                {
                    MeetingList.Add(new MeetingClass
                    {
                        Purpose = meetingFormReader["Purpose"].ToString(),
                        Type = meetingFormReader["Type"].ToString(),
                        Date = meetingFormReader["Date"].ToString(),

                    });


                }
                //Close your connection in DBClass
                DBClass.OfficeHoursDBConnection.Close();
                // Set a cookie to keep the user signed in for 30 minutes
                var options = new CookieOptions
                {
                    Expires = DateTime.Now.AddMinutes(30)
                };
                Response.Cookies.Append("username", HttpContext.Session.GetString("username"), options);
            }

            return Page();
        }

        public IActionResult OnPostNotifyHandler()
        {
            DBClass.NotifyStudent(StudentToNotify);
            return RedirectToPage("/Faculty/Index");
        }


        public IActionResult OnPostRemoveHandler()
         {
            return Page();
         }
    }
}



