using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using OfficeHours.Pages.DB;


namespace OfficeHours.Pages.Faculty
{
    public class FacultyDBLoginModel : PageModel
    {
		[BindProperty]
		public string Username { get; set; }
		[BindProperty]
		public string Password { get; set; }
		public void OnGet()
		{
		}

		public IActionResult OnPost()
		{
			if (DBClass.HashedFacParameterLogin(Username, Password))
			{
				HttpContext.Session.SetString("username", Username);
				ViewData["LoginMessage"] = "Login Successful!";
				DBClass.OfficeHoursDBConnection.Close();
				return RedirectToPage("/Faculty/Index");
			}
			else
			{
				ViewData["LoginMessage"] = "Username and/or Password Incorrect";
				DBClass.OfficeHoursDBConnection.Close();
				return Page();
			}
		}

		public IActionResult OnPostSignupHandler()
		{
			return RedirectToPage("/Faculty/HashedFacSignup");
		}
		
    }
}
