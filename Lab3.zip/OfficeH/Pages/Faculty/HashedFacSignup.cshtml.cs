using OfficeHours.Pages.DB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace OfficeHours.Pages.Faculty
{
    public class HashedFacSignupModel : PageModel
    {
        [BindProperty]
        public string Username { get; set; }
        [BindProperty]
        public string Password { get; set; }

        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            
            DBClass.CreateHashedFac(Username, Password);
            DBClass.OfficeHoursDBConnection.Close();

            ViewData["UserCreate"] = "User Successfully Created!";

            return RedirectToPage("/Faculty/FacultyDBLogin");
        }
    }
}
