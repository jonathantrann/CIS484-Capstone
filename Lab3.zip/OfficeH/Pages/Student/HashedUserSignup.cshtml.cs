using OfficeHours.Pages.DB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace OfficeHours.Pages.Student
{
    public class HashedUserSignupModel : PageModel
    {
        [BindProperty]
        public string Username { get; set; }
        [BindProperty]
        public string Password { get; set; }

        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            
            DBClass.CreateHashedUser(Username, Password);
            DBClass.OfficeHoursDBConnection.Close();

            ViewData["UserCreate"] = "User Successfully Created!";

            return RedirectToPage("/Student/DBLogin");
        }
    }
}
