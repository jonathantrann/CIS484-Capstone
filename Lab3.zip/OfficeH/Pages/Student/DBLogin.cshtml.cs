using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using OfficeHours.Pages.DB;
using Microsoft.AspNetCore.Session;

namespace OfficeHours.Pages.Student
{
    public class DBLoginModel : PageModel
    {
		[BindProperty]
		public string Username { get; set; }
		[BindProperty]
		public string Password { get; set; }

		public String LoginMessage { get; set; }
		public void OnGet(String logout)
        {
			if (logout != null) 
			{
				HttpContext.Session.Clear();
				LoginMessage = "Logged out successfully";
			}
        }

		public IActionResult OnPost()
		{
			if (DBClass.HashedParameterLogin(Username, Password))
			{
				HttpContext.Session.SetString("username", Username);
				ViewData["LoginMessage"] = "Login Succesful!";
				DBClass.OfficeHoursDBConnection.Close();
				return RedirectToPage("/Student/Index");
			}
			else
			{
				ViewData["Login Message"] = "Username and/or Password Incorrect";
				DBClass.OfficeHoursDBConnection.Close();
				return Page();
			}

		}

		public IActionResult OnPostSignupHandler()
		{
			return RedirectToPage("/Student/HashedUserSignup");
		}
	}
}
