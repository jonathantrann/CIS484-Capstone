using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Session;
using OfficeHours.Pages.DataClasses;
using OfficeHours.Pages.DB;
using System.Data.SqlClient;
using System.Linq;
using System.Collections.Generic;

namespace OfficeHours.Pages.Student
{
    public class IndexModel : PageModel
    {
        [BindProperty]

        public int FacultyID { get; set; }
        public List<SelectListItem> Faculty { get; set; }

        [BindProperty]
        public String FacultyName { get; set; }


        //[BindProperty]

        //public MeetingClass NewMeeting { get; set; }

        //public void OnGet()
        //{
        //    // Populate the User SELECT control
        //    SqlDataReader ShopperReader = DBClass.GeneralReaderQuery("SELECT * FROM FACULTY");

        //    Faculty = new List<SelectListItem>();

        //    while (ShopperReader.Read())
        //    {
        //        Faculty.Add(
        //            new SelectListItem(
        //                ShopperReader["FacultyLastName"].ToString(),
        //                ShopperReader["FacultyID"].ToString()));
        //    }

        //    DBClass.OfficeHoursDBConnection.Close();
        //}

        public void OnGet()
        {
            Faculty = DBClass.GetFacultyNames().Select(f => new SelectListItem
            {
                Value = FacultyID.ToString(),
                Text = FacultyName
            }).ToList();


            //SqlDataReader facultyReader = DBClass.facultyReader();

            if (HttpContext.Session.GetString("username") == null)
            {
                Response.Redirect("/Student/DBLogin");
            }
            else
            {
                // Populate the User SELECT control
                SqlDataReader ShopperReader = DBClass.GeneralReaderQuery("SELECT * FROM FACULTY");

                Faculty = new List<SelectListItem>();

                while (ShopperReader.Read())
                {
                    Faculty.Add(
                        new SelectListItem(
                            ShopperReader["FacultyName"].ToString(),
                            ShopperReader["FacultyID"].ToString()));
                }

                DBClass.OfficeHoursDBConnection.Close();

                // Set a cookie to keep the user signed in for 30 minutes
                var options = new CookieOptions
                {
                    Expires = DateTime.Now.AddMinutes(30)
                };
                Response.Cookies.Append("username", HttpContext.Session.GetString("username"), options);
            }
        }


        //public IActionResult OnGet()
        //{
        //    if (HttpContext.Session.GetString("username") == null)
        //    {
        //        return RedirectToPage("BasicLogin");
        //    }

        //    return Page();
        //}

        public IActionResult OnPost()
        {

            return RedirectToPage("/MeetingForm/NewMeeting");
            //return RedirectToPage("/Queue/Index");
        }

        public IActionResult OnPostSearchHandler(string searchTerm)
        {
            return RedirectToPage("/MeetingForm/NewMeeting");
        }
    }
}



    


