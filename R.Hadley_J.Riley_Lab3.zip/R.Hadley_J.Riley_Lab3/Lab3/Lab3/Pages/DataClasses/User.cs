﻿namespace Lab3.Pages.DataClasses
{
    public class User
    {
        public int StudentID { get; set; }

        public String? StudentFirst { get; set; }

        public String? StudentLast { get; set; }

        public String? StudentEmailAddress { get; set; }

        public String? StudentPhoneNumber { get; set; }
        public int StudentPartnerID { get; set; }
        public int CredentialsID { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }

    }
}
