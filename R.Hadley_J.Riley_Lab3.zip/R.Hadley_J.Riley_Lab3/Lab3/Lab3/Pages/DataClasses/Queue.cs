﻿namespace Lab3.Pages.DataClasses
{
    public class Queue
    {

        public int QueueID { get; set; }

        public String? StudentFirst { get; set; }

        public String? StudentLast { get; set; }

        public int StudentID { get; set; }

        public int OfficeHoursID { get; set; }
    }
}