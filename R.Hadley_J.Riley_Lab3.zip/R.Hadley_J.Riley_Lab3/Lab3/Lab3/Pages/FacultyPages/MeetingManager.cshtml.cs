using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Lab3.Pages.FacultyPages
{
    public class MeetingManagerModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
