using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Lab3.Pages.HTML
{
    public class HTML_HELPModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
