﻿    // Kaitlyn Steggall and Emmanuel Dadulla 2-19-2023

    using Lab_2.Pages.DataClasses;
    using System.Data.SqlClient;
    using System.Diagnostics;

    namespace Lab_2.Pages
    {
        public class DBClass
        {
            // Connection at the Class level
            public static SqlConnection Lab2DBConnection = new SqlConnection();

            // Connection Strings
            private static readonly String? Lab2DBConnString = "Server=Localhost;Database=Lab_2;Trusted_Connection=True";
            private static readonly String? AuthConnString = "Server=Localhost;Database=AUTH;Trusted_Connection=True";
            // Get Instructor Data From Database
            public static SqlDataReader InstructorReader()
            {
                SqlCommand cmdInsertReader = new SqlCommand();
                cmdInsertReader.Connection = Lab2DBConnection;
                cmdInsertReader.Connection.Close();
                cmdInsertReader.Connection.ConnectionString = Lab2DBConnString;
                cmdInsertReader.CommandText = "SELECT instructorID, instructorFirstName, instructorLastName FROM Instructor";
                cmdInsertReader.Connection.Open();
                SqlDataReader tempReader = cmdInsertReader.ExecuteReader();

                return tempReader;

            }
            //Get Class Data From Database
            public static SqlDataReader ClassReader(string studentID)
            {
                SqlCommand cmdClassRead = new SqlCommand();
                cmdClassRead.Connection = Lab2DBConnection;
                cmdClassRead.Connection.Close();
                cmdClassRead.Connection.ConnectionString = Lab2DBConnString;
                cmdClassRead.CommandText = "SELECT c.classID, c.className, i.instructorID FROM Class c, Instructor i, Student s, Has h WHERE i.instructorID = c.instructorID AND s.studentID = h.studentID AND c.classID = h.classID AND s.studentID = @studentID";
                cmdClassRead.Parameters.AddWithValue("@studentID", studentID);
                cmdClassRead.Connection.Open();
                SqlDataReader tempReader = cmdClassRead.ExecuteReader();

                return tempReader;

            }

            public static SqlDataReader OfficeHoursReader(string studentID)
            {
                SqlCommand cmdOfficeHoursRead = new SqlCommand();
                cmdOfficeHoursRead.Connection = Lab2DBConnection;
                cmdOfficeHoursRead.Connection.Close();
                cmdOfficeHoursRead.Connection.ConnectionString = Lab2DBConnString;
                cmdOfficeHoursRead.CommandText = "SELECT DISTINCT o.officeID, o.officeHours, o.officeHourDay, i.instructorFirstName, i.instructorLastName FROM OfficeHours o, Student s, Class c, Has h, Instructor i WHERE s.studentID = h.studentID AND h.classID = c.classID AND c.instructorID = i.instructorID AND i.instructorID = o.instructorID AND s.studentID = @studentID";
                cmdOfficeHoursRead.Parameters.AddWithValue("@studentID", studentID);
                cmdOfficeHoursRead.Connection.Open();
                SqlDataReader tempReader = cmdOfficeHoursRead.ExecuteReader();

                return tempReader;

            }

            public static SqlDataReader InstructorProfileRead(string instructorID)
            {
                SqlCommand cmdOfficeHoursRead = new SqlCommand();
                cmdOfficeHoursRead.Connection = Lab2DBConnection;
                cmdOfficeHoursRead.Connection.Close();
                cmdOfficeHoursRead.Connection.ConnectionString = Lab2DBConnString;
                cmdOfficeHoursRead.CommandText = "SELECT i.instructorID, i.instructorFirstName, i.instructorLastName, i.instructorEmail, o.officeHours, o.officeHourDay, o.officeLocation, c.className, c.classTime, c.classLocation\r\nFROM Instructor i, OfficeHours o, Class c\r\nWHERE i.instructorID = o.instructorID AND i.instructorID = c.instructorID AND i.instructorID = @instructorID;";
                cmdOfficeHoursRead.Parameters.AddWithValue("@instructorID", instructorID);
                cmdOfficeHoursRead.Connection.Open();
                SqlDataReader tempReader = cmdOfficeHoursRead.ExecuteReader();

                return tempReader;

            }

        public static void InsertOfficeHours(Attends a)
            {



                String sqlQuery = "INSERT INTO Attends (studentID,officeID) VALUES (@studentID, @officeID)";

                SqlCommand cmdInsertReader = new SqlCommand();
                cmdInsertReader.Connection = Lab2DBConnection;
                cmdInsertReader.Connection.Close();
                cmdInsertReader.Connection.ConnectionString = Lab2DBConnString;
                cmdInsertReader.CommandText = sqlQuery;
                cmdInsertReader.Parameters.AddWithValue("@studentID", a.studentID);
                cmdInsertReader.Parameters.AddWithValue("@officeID", a.officeID);


                cmdInsertReader.Connection.Open();

                cmdInsertReader.ExecuteNonQuery();

                // Debug.WriteLine(SelectedOfficeHoursID);
            }

        public static void AddStudentToQueue(Attends a)
        {
            String sqlQuery = "INSERT INTO Queue (studentID, officeID, position) VALUES (@studentID, @officeID, (SELECT COALESCE(MAX(position), 0) + 1 FROM Queue WHERE officeID = @officeID));";

            SqlCommand cmdInsertReader = new SqlCommand();
            cmdInsertReader.Connection = Lab2DBConnection;
            cmdInsertReader.Connection.Close();
            cmdInsertReader.Connection.ConnectionString = Lab2DBConnString;
            cmdInsertReader.CommandText = sqlQuery;
            cmdInsertReader.Parameters.AddWithValue("@studentID", a.studentID);
            cmdInsertReader.Parameters.AddWithValue("@officeID", a.officeID);


            cmdInsertReader.Connection.Open();

            cmdInsertReader.ExecuteNonQuery();
        }

        public static int getOfficeHoursCount(int studentID, int officeID)
            {
                string officeHourQuery =
                    "SELECT COUNT(*) FROM Attends a, Student s, OfficeHours o WHERE a.studentID = s.studentID AND o.officeID = a.officeID AND s.studentID = @studentID AND o.officeID = @officeID";

                SqlCommand cmdOfficeHour = new SqlCommand();
                cmdOfficeHour.Connection = Lab2DBConnection;
                cmdOfficeHour.Connection.Close();
                cmdOfficeHour.Connection.ConnectionString = Lab2DBConnString;

                cmdOfficeHour.CommandText = officeHourQuery;
                cmdOfficeHour.Parameters.AddWithValue("@studentID", studentID.ToString());
                cmdOfficeHour.Parameters.AddWithValue("@officeID", officeID.ToString());

                cmdOfficeHour.Connection.Open();

                // ExecuteScalar() returns back data type Object
                // Use a typecast to convert this to an int.
                // Method returns first column of first row.
                int rowCount = (int)cmdOfficeHour.ExecuteScalar();

                return rowCount;
            }

        public static int GetNumStudentsInQueue(int officeID)
        {
            int numStudents = 0;
            string query = "SELECT COUNT(*) FROM Queue WHERE officeID = @officeID";
            using (SqlConnection connection = new SqlConnection(Lab2DBConnString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@officeID", officeID);
                connection.Open();
                numStudents = (int)command.ExecuteScalar();
            }
            return numStudents;
        }

        public static int GetStudentPositionInQueue(int studentID, int officeID)
        {
            int position = -1;
            string query = "SELECT position FROM Queue WHERE officeID = @officeID AND studentID = @studentID";
            using (SqlConnection connection = new SqlConnection(Lab2DBConnString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@officeID", officeID);
                command.Parameters.AddWithValue("@studentID", studentID);
                connection.Open();
                object result = command.ExecuteScalar();
                if (result != null)
                {
                    position = (int)result;
                }
            }
            return position;
        }

        public static Tuple<int, int, bool> GetStudentQueueInfo(int officeID, int studentID)
        {
            int position = -1;
            int numStudents = 0;
            bool ready = false;
            string query = "SELECT position, ready FROM Queue WHERE officeID = @officeID AND studentID = @studentID";
            using (SqlConnection connection = new SqlConnection(Lab2DBConnString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@officeID", officeID);
                command.Parameters.AddWithValue("@studentID", studentID);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    position = (int)reader["position"];
                    ready = (bool)reader["ready"];
                }
                reader.Close();
            }
            numStudents = GetNumStudentsInQueue(officeID);
            return Tuple.Create(position, numStudents, ready);
        }


        public static SqlDataReader UserIDReader(string Username)
            {

                string userQuery =
                    "SELECT userID, Username, studentID, instructorID FROM Credentials WHERE Username = @Username";

                SqlCommand cmdUser = new SqlCommand();
                cmdUser.Connection = Lab2DBConnection;
                cmdUser.Connection.Close();
                cmdUser.Connection.ConnectionString = Lab2DBConnString;

                cmdUser.CommandText = userQuery;
                cmdUser.Parameters.AddWithValue("@Username", Username);

                cmdUser.Connection.Open();
                SqlDataReader tempReader = cmdUser.ExecuteReader();

                return tempReader;
            }

            public static SqlDataReader StudentSummaryReader(string studentID)
            {

                string userQuery =
                    "SELECT a.studentID, a.officeID, o.officeHours, o.officeHourDay, o.officeLocation, c.className, i.instructorFirstName, i.instructorLastName FROM Attends a, OfficeHours o, Class c, Instructor i, Student s WHERE s.studentID = a.studentID AND a.officeID = o.officeID AND o.instructorID = i.instructorID AND i.instructorID = c.instructorID AND s.studentID = @studentID";

                SqlCommand cmdUser = new SqlCommand();
                cmdUser.Connection = Lab2DBConnection;
                cmdUser.Connection.Close();
                cmdUser.Connection.ConnectionString = Lab2DBConnString;

                cmdUser.CommandText = userQuery;
                cmdUser.Parameters.AddWithValue("@studentID", studentID);

                cmdUser.Connection.Open();
                SqlDataReader tempReader = cmdUser.ExecuteReader();

                return tempReader;
            }




            public static void InsertMeeting(Meeting m)
            {
                String sqlQuery = "INSERT INTO Meeting(MeetingPurpose, " +
                    "MeetingDate, MeetingTime, MeetingLocation VALUES (";

                sqlQuery += m.MeetingPurpose + "',";
                sqlQuery += m.MeetingDate + "',";
                sqlQuery += m.MeetingTime + "',";
                sqlQuery += m.MeetingLocation + "')";


                SqlCommand cmdInsertReader = new SqlCommand();
                cmdInsertReader.Connection = Lab2DBConnection;
                cmdInsertReader.Connection.ConnectionString = Lab2DBConnString;
                cmdInsertReader.CommandText = sqlQuery;


                cmdInsertReader.Connection.Open();

                cmdInsertReader.ExecuteNonQuery();
            }


            public static void InsertClass(Class c)
            {
                String sqlQuery = "INSERT INTO Class(ClassName VALUES (";
                sqlQuery += c.className + "')";


                SqlCommand cmdInsertReader = new SqlCommand();
                cmdInsertReader.Connection = Lab2DBConnection;
                cmdInsertReader.Connection.ConnectionString = Lab2DBConnString;
                cmdInsertReader.CommandText = sqlQuery;


                cmdInsertReader.Connection.Open();

                cmdInsertReader.ExecuteNonQuery();

            }

            public static void InsertStudent(Student s)
            {
                String sqlQuery = "INSERT INTO Student(StudentName, StudentID VALUES(";
                sqlQuery += s.studentName + "',";
                sqlQuery += s.studentID + "')";


                SqlCommand cmdInsertReader = new SqlCommand();
                cmdInsertReader.Connection = Lab2DBConnection;
                cmdInsertReader.Connection.ConnectionString = Lab2DBConnString;
                cmdInsertReader.CommandText = sqlQuery;


                cmdInsertReader.Connection.Open();

                cmdInsertReader.ExecuteNonQuery();

            }

            public static int InsertStudentByValues(string studentName, string cellPhoneNumber)
            {
            String sqlQuery = "INSERT INTO Student (studentName,cellPhoneNumber) VALUES (@studentName, @cellPhoneNumber) SELECT SCOPE_IDENTITY()";
            SqlCommand cmdInsertReader = new SqlCommand();
            cmdInsertReader.Connection = Lab2DBConnection;
            cmdInsertReader.Connection.Close();
            cmdInsertReader.Connection.ConnectionString = Lab2DBConnString;

            cmdInsertReader.CommandText = sqlQuery;

            cmdInsertReader.Parameters.AddWithValue("@studentName", studentName);
            cmdInsertReader.Parameters.AddWithValue("@cellPhoneNumber", cellPhoneNumber);

            cmdInsertReader.Connection.Open();

            int newUserID = Convert.ToInt32(cmdInsertReader.ExecuteScalar());

            return newUserID;
        }

            public static int InsertCredentialByValues(string username, int studentID)
            {
                String sqlQuery = "INSERT INTO Credentials (Username, studentID) VALUES (@username, @studentID) SELECT SCOPE_IDENTITY()";
                SqlCommand cmdInsertReader = new SqlCommand();
                cmdInsertReader.Connection = Lab2DBConnection;
                cmdInsertReader.Connection.Close();
                cmdInsertReader.Connection.ConnectionString = Lab2DBConnString;

                cmdInsertReader.CommandText = sqlQuery;
                cmdInsertReader.Parameters.AddWithValue("@username", username);
                cmdInsertReader.Parameters.AddWithValue("@studentID", studentID);
                //cmdInsertReader.Parameters.AddWithValue("@instructorID", instructorID);

                cmdInsertReader.Connection.Open();

                int newUserID = Convert.ToInt32(cmdInsertReader.ExecuteScalar());

                return newUserID;
            }


            public static int validateUsername(string username)
            {
                string officeHourQuery = "SELECT COUNT(*) FROM Credentials where Username = @username";
                SqlCommand cmdOfficeHour = new SqlCommand();
                cmdOfficeHour.Connection = Lab2DBConnection;
                cmdOfficeHour.Connection.Close();
                cmdOfficeHour.Connection.ConnectionString = Lab2DBConnString;

                cmdOfficeHour.CommandText = officeHourQuery;
                cmdOfficeHour.Parameters.AddWithValue("@username", username);


                cmdOfficeHour.Connection.Open();

                // ExecuteScalar() returns back data type Object
                // Use a typecast to convert this to an int.
                // Method returns first column of first row.
                int rowCount = (int)cmdOfficeHour.ExecuteScalar();

                return rowCount;
            }

            public static int SecureLogin(string Username, string Password)
            {
                string loginQuery =
                    "SELECT COUNT(*) FROM Credentials where Username = @Username and Password = @Password";

                SqlCommand cmdLogin = new SqlCommand();
                cmdLogin.Connection = Lab2DBConnection;
                cmdLogin.Connection.Close();
                cmdLogin.Connection.ConnectionString = Lab2DBConnString;

                cmdLogin.CommandText = loginQuery;
                cmdLogin.Parameters.AddWithValue("@Username", Username);
                cmdLogin.Parameters.AddWithValue("@Password", Password);

                cmdLogin.Connection.Open();

                // ExecuteScalar() returns back data type Object
                // Use a typecast to convert this to an int.
                // Method returns first column of first row.
                int rowCount = (int)cmdLogin.ExecuteScalar();

                return rowCount;
            }

            public static SqlDataReader GeneralStoredProcedureReader(string StoredProcedureName)
            {

                SqlCommand cmdProcedureRead = new SqlCommand();
                cmdProcedureRead.Connection = Lab2DBConnection;
                cmdProcedureRead.Connection.ConnectionString = AuthConnString;
                cmdProcedureRead.CommandType = System.Data.CommandType.StoredProcedure;
                cmdProcedureRead.CommandText = StoredProcedureName;
                cmdProcedureRead.Connection.Open();
                SqlDataReader tempReader = cmdProcedureRead.ExecuteReader();

                return tempReader;

            }

            public static bool StoredProcedureLogin(string Username, string Password)
            {

                SqlCommand cmdProductRead = new SqlCommand();
                cmdProductRead.Connection = Lab2DBConnection;
                cmdProductRead.Connection.ConnectionString = AuthConnString;
                cmdProductRead.CommandType = System.Data.CommandType.StoredProcedure;
                cmdProductRead.Parameters.AddWithValue("@Username", Username);
                cmdProductRead.Parameters.AddWithValue("@Password", Password);
                cmdProductRead.CommandText = "sp_Lab3Login";
                cmdProductRead.Connection.Open();
                if (((int)cmdProductRead.ExecuteScalar()) > 0)
                {
                    return true;
                }

                return false;
            }

        //Creating a User and Login with Password Hashing
        public static bool HashedParameterLogin(string Username, string Password)
            {
                string loginQuery =
                    "SELECT Password FROM HashedCredentials WHERE Username = @Username";

                SqlCommand cmdLogin = new SqlCommand();
                cmdLogin.Connection = Lab2DBConnection;
                cmdLogin.Connection.Close();
                cmdLogin.Connection.ConnectionString = AuthConnString;

                cmdLogin.CommandText = loginQuery;
                cmdLogin.Parameters.AddWithValue("@Username", Username);

                cmdLogin.Connection.Open();

                // ExecuteScalar() returns back data type Object
                // Use a typecast to convert this to an int.
                // Method returns first column of first row.
                SqlDataReader hashReader = cmdLogin.ExecuteReader();
                if (hashReader.Read())
                {
                    string correctHash = hashReader["Password"].ToString();

                    if (PasswordHash.ValidatePassword(Password, correctHash))
                    {
                        return true;
                    }
                }

                return false;
            }


            public static void CreateHashedUser(string Username, string Password)
            {
                string loginQuery =
                    "INSERT INTO HashedCredentials (Username,Password) VALUES (@Username, @Password)";

                SqlCommand cmdLogin = new SqlCommand();
                cmdLogin.Connection = Lab2DBConnection;
                cmdLogin.Connection.Close();
                cmdLogin.Connection.ConnectionString = AuthConnString;

                cmdLogin.CommandText = loginQuery;
                cmdLogin.Parameters.AddWithValue("@Username", Username);
                cmdLogin.Parameters.AddWithValue("@Password", PasswordHash.HashPassword(Password));

                cmdLogin.Connection.Open();

                // ExecuteScalar() returns back data type Object
                // Use a typecast to convert this to an int.
                // Method returns first column of first row.
                cmdLogin.ExecuteNonQuery();

            }


            // General SELECT query
            // Can run and return results for any query if the results exist
            public static SqlDataReader GeneralReaderQuery(string sqlQuery)
            {
                SqlCommand cmdGeneralRead = new SqlCommand();
                cmdGeneralRead.Connection = Lab2DBConnection;
                cmdGeneralRead.Connection.ConnectionString = Lab2DBConnString;
                cmdGeneralRead.CommandText = sqlQuery;
                cmdGeneralRead.Connection.Open();
                SqlDataReader tempReader = cmdGeneralRead.ExecuteReader();

                return tempReader;
            }

            public static int NumberQuery(string NumberQuery)
            {
                // This method expects to receive an SQL SELECT
                // query that uses the COUNT command.

                SqlCommand cmdLogin = new SqlCommand();
                cmdLogin.Connection = Lab2DBConnection;
                cmdLogin.Connection.ConnectionString = Lab2DBConnString;
                cmdLogin.CommandText = NumberQuery;
                cmdLogin.Connection.Open();

                // ExecuteScalar() returns back data type Object
                // Use a typecast to convert this to an int.
                // Method returns first column of first row.
                int rowCount = (int)cmdLogin.ExecuteScalar();

                return rowCount;
            }
        }
    }