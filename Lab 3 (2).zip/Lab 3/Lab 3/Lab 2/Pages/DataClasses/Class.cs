﻿namespace Lab_2.Pages.DataClasses
{
    public class Class
    {
        public int classID { get; set; }

        public String className { get; set; }

        public int classLocation { get; set; }

        public int classTime { get; set; }

        public String classDate { get; set; }

        public String classDescription { get; set; }

        public int instructorID { get; set; }
    }
}
