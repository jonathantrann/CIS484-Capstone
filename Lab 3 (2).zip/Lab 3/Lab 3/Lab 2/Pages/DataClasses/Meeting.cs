﻿namespace Lab_2.Pages.DataClasses
{
    public class Meeting
    {
        public int MeetingID { get; set; }

        public String MeetingPurpose { get; set; }

        public DateTime MeetingDate { get; set; }

        public String MeetingTime { get; set; }

        public int MeetingLocation { get; set; }

        public int instructorID { get; set; }

    }
}
