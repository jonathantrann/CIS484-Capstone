﻿namespace Lab_2.Pages.DataClasses
{
    public class Credentials
    {
        public int userID { get; set; }

        public String Username { get; set; }

        public String Password { get; set; }

        public int studentID { get; set; }

        public int instructorID { get; set; }

    }
}
