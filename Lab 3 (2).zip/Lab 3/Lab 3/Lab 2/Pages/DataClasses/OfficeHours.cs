﻿namespace Lab_2.Pages.DataClasses
{
    public class OfficeHours
    {
        public int officeID { get; set; }
        public String officeHours { get; set; }
        public String officeDay { get; set; }
        public String officeLocation { get; set; }
        public int instructorID { get; set; }
    }
}
