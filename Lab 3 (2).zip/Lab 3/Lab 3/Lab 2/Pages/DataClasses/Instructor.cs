﻿namespace Lab_2.Pages.DataClasses
{
    public class Instructor
    {
        public int InstructorID { get; set; }

        public String InstructorFirstName { get; set; }

        public String InstructorLastName { get; set; }

        public String InstructorEmail { get; set; }
    }
}
