﻿namespace Lab_2.Pages.DataClasses
{
    public class Student
    {
        public int studentID { get; set; }
        public String studentName { get; set; }
        public String cellPhoneNumber { get; set; }
        public int partnerID { get; set; }
        public int queueID { get; set; }


    }
}
