﻿namespace Lab_2.Pages.DataClasses
{
    public class HashedCredentials
    {
        public int hashID { get; set; }

        public String Username { get; set; }

        public String Password { get; set; }
    }
}
