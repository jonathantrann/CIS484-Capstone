// Kaitlyn Steggall and Emannuel Dadulla 2-19-2023


using Lab_2.Pages.DataClasses;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Diagnostics;

namespace Lab_2.Pages
{
    public class LoginModel : PageModel
    {
        [BindProperty]
        public string Username { get; set; }
        [BindProperty]
        public string Password { get; set; }

        public String LoginMessage { get; set; }

        // log out logic
        public void OnGet(String logout)
        {
            if (logout != null)
            {
                HttpContext.Session.Clear();
                LoginMessage = "Logged out Successfully";
            }

        }

        public IActionResult OnPost()
        {
            if (DBClass.HashedParameterLogin(Username, Password))
            {
                Debug.WriteLine(PasswordHash.HashPassword(Password));
                // id, username, role (student or faculty)
                HttpContext.Session.SetString("Username", Username);
                SqlDataReader userReader = DBClass.UserIDReader(Username);
                userReader.Read();
                string studentID = "";
                if (userReader["studentID"] != null)
                {
                    studentID = userReader["studentID"].ToString();
                }
                string instructorID = "";
                if (userReader["instructorID"] != null)
                {
                    instructorID = userReader["instructorID"].ToString();
                }
                if (!studentID.Equals(""))
                {
                    HttpContext.Session.SetString("Role", "Student");
                    HttpContext.Session.SetString("ID", studentID);
                }
                else if (!instructorID.Equals(""))
                {
                    HttpContext.Session.SetString("Role", "Instructor");
                    HttpContext.Session.SetString("ID", instructorID);
                }



                ViewData["LoginMessage"] = "Login Successful!";
                ViewData["Username"] = Username;
                // Line of code will redirect after logging in 

                Debug.WriteLine(HttpContext.Session.GetString("Username"));
                Debug.WriteLine(HttpContext.Session.GetString("Role"));
                Debug.WriteLine(HttpContext.Session.GetString("ID"));
                return RedirectToPage("LandingPage");

            }
            else
            {
                // Tells user that the username or password is incorrect and makes them try again
                ViewData["LoginMessage"] = "Username and/or Password Incorrect";

            }

            DBClass.Lab2DBConnection.Close();

            return Page();


        }
    }
}
