using Lab_2.Pages.DataClasses;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Diagnostics;

namespace Lab_2.Pages
{

    public class StudentHomePageModel : PageModel
    {
        [BindProperty]
        public List<Instructor> Instructors { get; set; }
        [BindProperty]
        public List<Instructor> FilteredInstructors { get; set; }
        [BindProperty]

        public string ReadyID { get; set; }
        public bool IsReadyForOfficeHours { get; set; }
        public string InstructorName { get; set; }
        public string OfficeHoursMessage { get; set; }

        public StudentHomePageModel()
        {
            // Make Instructor List
            Instructors = new List<Instructor>();
            FilteredInstructors = new List<Instructor>();
        }

        public IActionResult OnGet()
        {
            Debug.WriteLine(HttpContext.Session.GetString("ID"));
            if (HttpContext.Session.GetString("ID") == null)
            {
                return RedirectToPage("Login");
                //return Page();
            }

            // Check for signed up office hours
            string studentID = HttpContext.Session.GetString("ID");
            SqlDataReader officeHoursReader = DBClass.OfficeHoursReader(studentID);
            while (officeHoursReader.Read())
            {
                // Get the instructor name for the first signed up office hours
                Tuple<int, int, bool> queueInfo = DBClass.GetStudentQueueInfo(int.Parse(officeHoursReader["officeID"].ToString()), int.Parse(HttpContext.Session.GetString("ID")));
                if (queueInfo.Item3)
                {
                    Debug.WriteLine("test2");
                    IsReadyForOfficeHours = true;
                    InstructorName = officeHoursReader["instructorFirstName"].ToString() + " " + officeHoursReader["instructorLastName"].ToString();

                }
                //int instructorID = int.Parse(officeHoursReader["InstructorID"].ToString());
                //SqlDataReader instructorReader = DBClass.InstructorProfileRead(instructorID.ToString());
                //instructorReader.Read();
                //InstructorName = officeHoursReader["instructorFirstName"].ToString() + " " + officeHoursReader["instructorLastName"].ToString();

                // Set the office hours message
                //if (ready)
                //{
                //    OfficeHoursMessage = $"You are ready to be seen by {instructorName}";
                //}
            }

            return Page();
        }

        public async Task<IActionResult> OnPostSearchAsync(string searchTerm)
        {
            DBClass.Lab2DBConnection.Close();

            SqlDataReader instructorReader = DBClass.InstructorReader();
            while (instructorReader.Read())
            {
                Instructors.Add(new Instructor
                {
                    InstructorID = int.Parse(instructorReader["InstructorID"].ToString()),
                    InstructorFirstName = instructorReader["InstructorFirstName"].ToString(),
                    InstructorLastName = instructorReader["InstructorLastName"].ToString()
                });

                //Debug.WriteLine(int.Parse(instructorReader["InstructorID"].ToString()));
                //Debug.WriteLine(instructorReader["InstructorFirstName"].ToString());
                //Debug.WriteLine(instructorReader["InstructorLastName"].ToString());

                //Debug.WriteLine(Instructors.Count);
            }
            DBClass.Lab2DBConnection.Close();


            Debug.WriteLine($"Search term: {searchTerm}");

            FilteredInstructors = Instructors
            .Where(instructor =>
                instructor.InstructorFirstName.IndexOf(searchTerm, 0, StringComparison.OrdinalIgnoreCase) != -1 ||
                instructor.InstructorLastName.IndexOf(searchTerm, 0, StringComparison.OrdinalIgnoreCase) != -1)
            .ToList();

            foreach (Instructor instructor in FilteredInstructors)
            {
                Debug.WriteLine($"Instructor ID: {instructor.InstructorID}");
                Debug.WriteLine($"Instructor Name: {instructor.InstructorFirstName} {instructor.InstructorLastName}");
                Debug.WriteLine($"Instructor Email: {instructor.InstructorEmail}");
                Debug.WriteLine("");
            }

            return Page();
        }


    }
}
