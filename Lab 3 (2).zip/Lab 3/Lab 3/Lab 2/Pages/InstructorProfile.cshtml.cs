using Lab_2.Pages.DataClasses;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Diagnostics;

namespace Lab_2.Pages
{
    public class InstructorProfileModel : PageModel
    {

        public string InstructorID { get; set; }

        public int instructorID { get; set; }
        public string instructorFirstName { get; set; }
        public string instructorLastName { get; set; }
        public string instructorEmail { get; set; }
        public string officeHours { get; set; }
        public string officeHourDay { get; set; }
        public string officeLocation { get; set; }
        public string className { get; set; }
        public string classTime { get; set; }
        public string classLocation { get; set; }

        public InstructorProfileModel()
        {
        }

        public IActionResult OnGet()
        {

            Debug.WriteLine(HttpContext.Session.GetString("ID"));
            if (HttpContext.Session.GetString("ID") == null)
            {

                return RedirectToPage("Login");
            }

            SqlDataReader instructorProfileRead = DBClass.InstructorProfileRead(Request.Query["id"]);
            instructorProfileRead.Read();
            instructorID = int.Parse(instructorProfileRead["instructorID"].ToString());
            instructorFirstName = instructorProfileRead["instructorFirstName"].ToString();
            instructorLastName = instructorProfileRead["instructorLastName"].ToString();
            instructorEmail = instructorProfileRead["instructorEmail"].ToString();
            officeHours = instructorProfileRead["officeHours"].ToString();
            officeHourDay = instructorProfileRead["officeHourDay"].ToString();
            officeLocation = instructorProfileRead["officeLocation"].ToString();
            className = instructorProfileRead["className"].ToString();
            classTime = instructorProfileRead["classTime"].ToString();
            classLocation = instructorProfileRead["classLocation"].ToString();
            DBClass.Lab2DBConnection.Close();

            return Page();
        }
    }
}
