// Kaitlyn Steggall and Emannuel Dadulla 2-19-2023

using Lab_2.Pages.DataClasses;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace Lab_2.Pages
{
    public class OHSummaryPageModel : PageModel
    {
        public Dictionary<int, string> OfficeHoursDict { get; set; }

        public OHSummaryPageModel()
        {
            OfficeHoursDict = new Dictionary<int, string>();
        }

        // Gets office hour data form the database
        public IActionResult OnGet()
        {
            SqlDataReader studentSummaryReader = DBClass.StudentSummaryReader(HttpContext.Session.GetString("ID"));
            while (studentSummaryReader.Read())
            {
                int officeHoursID = int.Parse(studentSummaryReader["officeID"].ToString());
                string instructorFirstName = studentSummaryReader["instructorFirstName"].ToString();
                string instructorLastName = studentSummaryReader["instructorLastName"].ToString();
                string officeHourDay = studentSummaryReader["officeHourDay"].ToString();
                string officeHours = studentSummaryReader["officeHours"].ToString();
                OfficeHoursDict.TryAdd(officeHoursID, instructorFirstName + " " + instructorLastName + " " + officeHourDay + " " + officeHours);
            }
            DBClass.Lab2DBConnection.Close();

            return Page();
        }
    }
}
