// Kaitlyn Steggall and Emannuel Dadulla 2-19-2023


using Lab_2.Pages.DataClasses;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;

namespace Lab_2.Pages
{
    public class Index1Model : PageModel
    {
        [BindProperty]
        [Required]
        public String StudentName { get; set; }

        [Required]
        public String PhoneNumber { get; set; }

        [BindProperty, DataType(DataType.Date)]
        [Required]
        public DateTime Date { get; set; }

        [BindProperty, DataType(DataType.Time)]
        [Required]
        public TimeSpan Time { get; set; }

        [BindProperty]
        [Required]
        public String MeetingPurpose { get; set; }

        [BindProperty]
        public string Partner { get; set; }
        public string[] Partners = new[] { "Yes", "No" };

        [BindProperty]
        public String PartnerName { get; set; }

        [BindProperty]
        [Required]
        public List<Instructor> Instructors { get; set; }

        [BindProperty]
        public Meeting NewMeeting { get; set; }

        [BindProperty]
        public Class NewClass { get; set; }

        [BindProperty]
        public Student NewStudent { get; set; }

        public Index1Model()
        {
            // Make Instructor List
            Instructors = new List<Instructor>();
        }

        public IActionResult OnGet()
        {

             if (HttpContext.Session.GetString("ID") == null)
            {

                return RedirectToPage("Login");
                //return Page();
            }
            // Get instructor data
            SqlDataReader instructorReader = DBClass.InstructorReader();
            while (instructorReader.Read())
            {
                Instructors.Add(new Instructor
                {
                    InstructorID = int.Parse(instructorReader["InstructorID"].ToString()),
                    InstructorFirstName = instructorReader["InstructorFirstName"].ToString(),
                    InstructorLastName = instructorReader["InstructorLastName"].ToString()
                });
            }
            DBClass.Lab2DBConnection.Close();

            return Page();
        }

        
        
        public IActionResult OnPostPopulateHandler()
        {
            //Create Populate button
            ModelState.Clear();
            StudentName = "John Doe";
            PhoneNumber = "(757) 555 - 1234";
            MeetingPurpose = "Going over test";
            Partner = "Yes";
            PartnerName = "Jane Doe";
            SqlDataReader instructorReader = DBClass.InstructorReader();
            while (instructorReader.Read())
            {
                Instructors.Add(new Instructor
                {
                    InstructorID = int.Parse(instructorReader["InstructorID"].ToString()),
                    InstructorFirstName = instructorReader["InstructorFirstName"].ToString(),
                    InstructorLastName = instructorReader["InstructorLastName"].ToString()
                });
            }
            DBClass.Lab2DBConnection.Close();


            return Page();


        }
        public IActionResult OnPostClearHandler()
        {
            //Create Clear Button
            ModelState.Clear();
            StudentName = "";
            PhoneNumber = "";
            MeetingPurpose = "";
            Partner = "";
            PartnerName = "";
            SqlDataReader instructorReader = DBClass.InstructorReader();
            while (instructorReader.Read())
            {
                Instructors.Add(new Instructor
                {
                    InstructorID = int.Parse(instructorReader["InstructorID"].ToString()),
                    InstructorFirstName = instructorReader["InstructorFirstName"].ToString(),
                    InstructorLastName = instructorReader["InstructorLastName"].ToString()
                });
            }
            DBClass.Lab2DBConnection.Close();

            return Page();
        }


        public IActionResult OnPost()
        {
            DBClass.InsertMeeting(NewMeeting);
            DBClass.InsertClass(NewClass);
            DBClass.InsertStudent(NewStudent);

            DBClass.Lab2DBConnection.Close();

            return RedirectToPage("Index");
        }
    }
}
