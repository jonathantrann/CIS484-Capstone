using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Lab_2.Pages
{
    public class OfficeHoursManagementModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
