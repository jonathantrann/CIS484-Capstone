// Kaitlyn Steggall and Emannuel Dadulla 2-19-2023


using Lab_2.Pages.DataClasses;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Drawing.Printing;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Lab_2.Pages
{
    public class OfficeHoursModel : PageModel
    {
        public int SelectedClassID { get; set; }

        [BindProperty]
        [Required]
        public int SelectedOfficeHoursID { get; set; }

        public Attends NewOfficeHour { get; set; }
        public Dictionary<int, string> OfficeHoursDict { get; set; }

        public OfficeHoursModel()
        {
            OfficeHoursDict = new Dictionary<int, string>();
            NewOfficeHour = new Attends();
        }

        public IActionResult OnGet()
        {

            Debug.WriteLine(HttpContext.Session.GetString("ID"));
            if (HttpContext.Session.GetString("ID") == null)
            {

                return RedirectToPage("Login");
                //return Page();
            }

            // Reads office hour data from the database
            SqlDataReader officeHoursReader = DBClass.OfficeHoursReader(HttpContext.Session.GetString("ID"));
            while (officeHoursReader.Read())
            {
                int officeHoursID = int.Parse(officeHoursReader["officeID"].ToString());
                string instructorFirstName = officeHoursReader["instructorFirstName"].ToString();
                string instructorLastName = officeHoursReader["instructorLastName"].ToString();
                string officeHourDay = officeHoursReader["officeHourDay"].ToString();
                string officeHours = officeHoursReader["officeHours"].ToString();
                OfficeHoursDict.Add(officeHoursID, instructorFirstName + " " + instructorLastName + " " + officeHourDay + " " + officeHours);
            }
            DBClass.Lab2DBConnection.Close();

            return Page();

        }
        // Takes office hour data that student inputs and redirects them to the summary page
        public IActionResult OnPost()
        {
            NewOfficeHour.studentID = int.Parse(HttpContext.Session.GetString("ID"));
            NewOfficeHour.officeID = SelectedOfficeHoursID;

            if (DBClass.getOfficeHoursCount(NewOfficeHour.studentID, NewOfficeHour.officeID) == 0)
            {
                DBClass.InsertOfficeHours(NewOfficeHour);

                DBClass.AddStudentToQueue(NewOfficeHour);
            }
            else
            {
                Debug.WriteLine("oh no");
            }


            DBClass.Lab2DBConnection.Close();

            return RedirectToPage("OHSummaryPage");

        }

        // Populate Button
        public IActionResult OnPostPopulateHandler()
        {
            ModelState.Clear();

            return Page();
        }
        public IActionResult OnPostClearHandler()
        {
            //Create Clear Button
            ModelState.Clear();

            return Page();
        }
    }
}