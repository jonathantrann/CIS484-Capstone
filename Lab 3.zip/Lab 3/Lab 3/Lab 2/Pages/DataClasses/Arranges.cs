﻿namespace Lab_2.Pages.DataClasses
{
    public class Arranges
    {
        public int studentID { get; set; }

        public int meetingID { get; set; }
    }
}
