﻿namespace Lab_2.Pages.DataClasses
{
    public class Attends
    {
        public int studentID { get; set; }

        public int officeID { get; set; }
    }
}
