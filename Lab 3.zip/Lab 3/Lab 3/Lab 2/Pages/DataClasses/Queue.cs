﻿namespace Lab_2.Pages.DataClasses
{
    public class Queue
    {
        public int queueID { get; set; }
        public int waitingRoom { get; set; }
        public int queueNumber { get; set; }
        public int queueSize { get; set; }
    }
}
