﻿namespace Lab_2.Pages.DataClasses
{
    public class Has
    {
        public int studentID { get; set; }

        public int classID { get; set; }
    }
}
