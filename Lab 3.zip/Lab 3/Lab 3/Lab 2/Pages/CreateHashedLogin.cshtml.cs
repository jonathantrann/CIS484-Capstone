using Lab_2.Pages.DataClasses;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;

namespace Lab_2.Pages
{
    public class CreateHashedLoginModel : PageModel
    {
        [BindProperty]
        public string Username { get; set; }
        [BindProperty]
        public string Password { get; set; }

        [BindProperty]
        [Required]
        public String StudentName { get; set; }

        [BindProperty]
        [Required]
        public String PhoneNumber { get; set; }

        //[BindProperty]
        //public Student NewStudent { get; set; }

        public void OnGet()
        {
            //NewStudent = new Student();
        }

        public IActionResult OnPost()
        {
            // Perform Validation First on Form
            // then...

            if (DBClass.validateUsername(Username) == 0)
            {

                int studentId = DBClass.InsertStudentByValues(StudentName, PhoneNumber);
                int userId = DBClass.InsertCredentialByValues(Username, studentId);

                DBClass.CreateHashedUser(Username, Password);
                DBClass.Lab2DBConnection.Close();

                // Perform actual logic to check if user was successfully
                //  added in your projects but for demo purposes we can say:

                ViewData["UserCreate"] = "User Successfully Created!";
                Debug.WriteLine(userId);
                Debug.WriteLine(studentId);
                Debug.WriteLine(Username);
                Debug.WriteLine(PhoneNumber);
            }
            else
            {
                ViewData["UserCreate"] = "joe biden";
            }

            return RedirectToPage("Login");
        }
    }
}
