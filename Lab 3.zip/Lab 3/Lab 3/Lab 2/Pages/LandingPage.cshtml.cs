// Kaitlyn Steggall and Emannuel Dadulla 2-19-2023


using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Lab_2.Pages
{
    public class LandingPageModel : PageModel
    {
        public IActionResult OnGet()
        {
            if (HttpContext.Session.GetString("Username") == null)
            {
                return RedirectToPage("Login");
            }
            return Page();
        }
    }
}
